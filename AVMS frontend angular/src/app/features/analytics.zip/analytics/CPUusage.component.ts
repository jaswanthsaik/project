import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from '@angular/router';
import * as am5 from '@amcharts/amcharts5';
import * as am5xy from '@amcharts/amcharts5/xy';
import * as am5themes_Animated from '@amcharts/amcharts5/themes/Animated';
import { BreadcrumbsItem } from "src/app/shared/models/breadcrumbs-item";
import * as Highcharts from 'highcharts';
import HighchartsMore from 'highcharts/highcharts-more';
import HighchartsTreemap from 'highcharts/modules/treemap';

HighchartsMore(Highcharts);

HighchartsTreemap(Highcharts);

@Component({
  selector: 'app-CPUusage',
  templateUrl: './CPUusage.component.html',
  styleUrls: ['./CPUusage.component.scss']
})


export class CPUusage implements OnInit {
  chart: any;


  breadcrumbs: BreadcrumbsItem[] = [
    { label: 'Home', url: '/' },
    { label: 'analytics', url: '' },
  ];


  selectedSummary: number | null = null;

  constructor(private router: Router) { }


  showUserData(summaryIndex: number): void {
    this.selectedSummary = summaryIndex;
    if (summaryIndex === 1) {
      this.router.navigate(["/analytics"]);
    }
    if (summaryIndex === 2) {
      this.router.navigate(["/analytics."]);
    }
    if (summaryIndex === 4) {
      this.router.navigate(["/analytics..."]);
    }
  }



  ngOnInit(): void {
    const defaultSummaryIndex = 3;
    this.showUserData(defaultSummaryIndex);
    this.showUserData(defaultSummaryIndex);
  }
}