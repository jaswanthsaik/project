import { Component, OnInit } from "@angular/core";
import { Router } from '@angular/router';
import * as am5 from '@amcharts/amcharts5';
import * as am5xy from '@amcharts/amcharts5/xy';
import * as am5themes_Animated from '@amcharts/amcharts5/themes/Animated';
import { BreadcrumbsItem } from "src/app/shared/models/breadcrumbs-item";
import * as Highcharts from 'highcharts';
import HighchartsMore from 'highcharts/highcharts-more';
import HighchartsTreemap from 'highcharts/modules/treemap';
import HC_exporting from 'highcharts/modules/exporting';
HC_exporting(Highcharts);
HighchartsMore(Highcharts);
HighchartsTreemap(Highcharts);

@Component({
  selector: 'app-manageByExceptions',
  templateUrl: './manageByExceptions.html',
  styleUrls: ['./manageByExceptions.scss']
})
export class manageByExceptions implements OnInit {
  chart: any;
  breadcrumbs: BreadcrumbsItem[] = [
    { label: 'Home', url: '/' },
    { label: 'analytics', url: '' },
  ];
  selectedSummary: number | null = null;

  constructor(private router: Router) { }

  showUserData(summaryIndex: number): void {
    this.selectedSummary = summaryIndex;
    if (summaryIndex === 1) {
      this.router.navigate(["/analytics"]);
    }
    if (summaryIndex === 3) {
      this.router.navigate(["/analytics.."]);
    }
    if (summaryIndex === 4) {
      this.router.navigate(["/analytics..."]);
    }
  }

  ngOnInit(): void {
    const defaultSummaryIndex = 2;
    this.showUserData(defaultSummaryIndex);
    this.showUserData(defaultSummaryIndex);

    // Chart 1 - chartdiv3
    const root3 = am5.Root.new('chartdiv3');
    const chart1 = root3.container.children.push(
      am5xy.XYChart.new(root3, {
        panX: false,
        panY: false,
        wheelX: 'panX',
        wheelY: 'zoomX',
        layout: root3.horizontalLayout,
      })
    );

    const yRenderer1 = am5xy.AxisRendererY.new(root3, {});
    const yAxis1 = chart1.yAxes.push(
      am5xy.CategoryAxis.new(root3, {
        categoryField: 'year',
        renderer: yRenderer1,
        tooltip: am5.Tooltip.new(root3, {}),
      })
    );

    yRenderer1.grid.template.setAll({
      location: 1,
    });

    const data1 = [
      {
        year: 'East US',
        'scheduled and scaled': 0.103,
        'scheduled only': 0.17,
        'scaled only': 0.068,
        'neither': 0.103,
        'white': 2.95,
      },
    ];

    yAxis1.data.setAll(data1);
    const xAxis1 = chart1.xAxes.push(
      am5xy.ValueAxis.new(root3, {
        min: 0,
        max: 13,
        strictMinMax: true,
        calculateTotals: true,
        renderer: am5xy.AxisRendererX.new(root3, {
          strokeOpacity: 0.1,
        }),
      })
    );

    function makeSeries1(
      name: string,
      fieldName: string,
      color: am5.Color,
      columnWidth: number,
      columnHeight: number
    ) {
      const series1 = chart1.series.push(
        am5xy.ColumnSeries.new(root3, {
          name: name,
          stacked: true,
          xAxis: xAxis1,
          yAxis: yAxis1,
          valueXField: fieldName,
          valueXShow: 'valueXTotalPercent',
          categoryYField: 'year',
          fill: color,
        })
      );
      series1.columns.template.set('width', am5.percent(columnWidth * 18));
      series1.columns.template.set('height', columnHeight);
      series1.columns.template.setAll({
        tooltipText:
          "{categoryY}\n{name}:{valueXTotalPercent.formatNumber('#.#')}",
        tooltipY: am5.percent(1),
      });
      series1.data.setAll(data1);
      series1.appear();
      series1.bullets.push(function () {
        return am5.Bullet.new(root3, {
          sprite: am5.Label.new(root3, {
            text: "{valueXTotalPercent.formatNumber('#.#')}",
            fill: root3.interfaceColors.get('alternativeText'),
            centerY: am5.p50,
            centerX: am5.p50,
            populateText: true,
          }),
        });
      });
    }
    makeSeries1('scheduled and scaled', 'scheduled and scaled', am5.color('#006580'), 0.6, 80);
    makeSeries1('scheduled only', 'scheduled only', am5.color('#e0bd8d'), 0.6, 80);
    makeSeries1('scaled only', 'scaled only', am5.color('#10cfc9'), 0.6, 80);
    makeSeries1('neither', 'neither', am5.color('#87205d'), 0.6, 80);
    makeSeries1('', 'white', am5.color('#ffffff'), 0, 0.1);
    chart1.appear(1000);

    // Chart 2 - container
      const chartConfig2: Highcharts.Options = {
        chart: {
          type: 'treemap',
          backgroundColor: '#f9f9f9'
        },
        title: {
          text: 'colored by number of available recommendations',
          align: 'left',
          style: {
            fontSize: '13px',
            fontWeight: 'normal',
            color: '#bca395'
          }
        },
        series: [{
          type: 'treemap',
          layoutAlgorithm: 'stripes',
          alternateStartingDirection: true,
          borderColor: '#fff',
          borderRadius: 0,
          borderWidth: 2,
          dataLabels: {
            style: {
              textOutline: 'none',
            }
          },
          levels: [{
            level: 1,
            layoutAlgorithm: 'sliceAndDice',
            dataLabels: {
              enabled: true,
              align: 'left',
              verticalAlign: 'top',
              style: {
                fontSize: '13px',
                fontWeight: 'normal'
              }
            }
          }],
          data: [{
            id: 'A',
            name: 'Subscription',
            color: '#10cfc9'
          }, {
            id: 'B',
            name: 'subscription',
            color: '#006580'
          }, {
            id: 'C',
            name: 'subscription',
            color: '#87205d'
          }, {
            name: 'Medium',
            parent: 'A',
            value: 60
          }, {
            name: 'Low',
            parent: 'A',
            value: 16
          }, {
            name: 'High',
            parent: 'B',
            value: 13
          }, {
            name: 'Low',
            parent: 'C',
            value: 13
          }]
        }],
        tooltip: {
          useHTML: true,
          pointFormat: 'The area of <b>{point.name}</b> is <b>{point.value} km<sup>2</sup></b>'
        }
      };

      Highcharts.chart('container', chartConfig2);


    // Chart 3 - container2
    const chartConfig3: Highcharts.Options = {
      chart: {
        type: 'bar'
      }, title: {
        text: 'times the instances hit the tresholds',
        align: 'left',
        style: {
          fontSize: '13px',
          fontWeight: 'normal',
          color: '#bca395'
        }
      },
      legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        symbolWidth: 12,
        symbolHeight: 12,
        symbolRadius: 0,
        y: 20 
      },
      xAxis: {
        categories: ['Dev Ensar Accounts']
      },
      yAxis: {
        allowDecimals: false,
        min: 0,
        max: 6000,
        title: {
          text: 'over 75%...,below 20%compar...',
          style: {
            fontSize: '10px',
            fontWeight: 'normal',
            color: '#bca395'
          }
        },
        labels: {
          formatter: function () {
            
            const value = Number(this.value); 
            return value >= 1000 ? (value / 1000).toString() + 'k' : value.toString();
          }
        }
      },
      tooltip: {
        format: '<b>{key}</b><br/>{series.name}: {y}<br/>' + 'Total: {point.stackTotal}'
      },
      plotOptions: {
        bar: {
          states: {
            inactive: {
              opacity: 1 
            }
          },
          dataLabels: {
            enabled: true,
            inside: false, 
            verticalAlign: 'middle',
            style: {
              fontWeight: 'bold'
            },
            formatter: function () {
             
              const value = this.y ?? 0;
              return value >= 1000 ? (value / 1000).toString() + 'k' : value.toString();
            }
    
          }
        }
      },
      series: [
        {
          type: 'bar',
          name: 'over 75% and',
          data: [4500],
          color: '#006580'
        },
        {
          type: 'bar',
          name: 'below 20% comparision',
          data: [4500],
          color: '#87205d'
        }
      ]
    };
    
    Highcharts.chart('container2', chartConfig3);
  }
}
