import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from '@angular/router';
import * as am5 from '@amcharts/amcharts5';
import * as am5xy from '@amcharts/amcharts5/xy';
import * as am5themes_Animated from '@amcharts/amcharts5/themes/Animated';
import { BreadcrumbsItem } from "src/app/shared/models/breadcrumbs-item";
import * as Highcharts from 'highcharts';
import HighchartsMore from 'highcharts/highcharts-more';
import HighchartsTreemap from 'highcharts/modules/treemap';
import HC_exporting from 'highcharts/modules/exporting';
HC_exporting(Highcharts);
HighchartsMore(Highcharts);
HighchartsTreemap(Highcharts);

@Component({
  selector: 'app-Recommendations',
  templateUrl: './Recommendations.component.html',
  styleUrls: ['./Recommendations.component.scss']
})


export class Recommendations implements OnInit {
  tableData = [
    { resourceName: 'apigwvm 1', resourceType: 'Subscription', resourceTypeName: 'HighAvailability', impact: 'Medium', subscription: 'apigw', category: 'Azure subscription 1' },
    { resourceName: 'apigwvm 2', resourceType: 'Subscription', resourceTypeName: 'HighAvailability', impact: 'Medium', subscription: 'apigw', category: 'Azure subscription 1' },
    { resourceName: 'Fedora', resourceType: 'Subscription', resourceTypeName: 'HighAvailability', impact: 'Medium', subscription: 'Rgroup3', category: 'Azure subscription 1' },
    { resourceName: 'Kiran', resourceType: 'Subscription', resourceTypeName: 'HighAvailability', impact: 'Medium', subscription: 'myrg', category: 'Azure subscription 1' },
    { resourceName: 'Kiran2', resourceType: 'VirtualMachine', resourceTypeName: 'HighAvailability', impact: 'Low', subscription: 'myrg', category: 'Azure subscription 1' },
    { resourceName: 'Kiran3', resourceType: 'Subscription', resourceTypeName: 'Cost', impact: 'High', subscription: 'myrg', category: 'Azure subscription 1' },
    { resourceName: 'linux', resourceType: 'Subscription', resourceTypeName: 'HighAvailability', impact: 'Medium', subscription: 'myrg', category: 'Azure subscription 1' },
    { resourceName: 'project', resourceType: 'Subscription', resourceTypeName: 'HighAvailability', impact: 'Medium', subscription: 'apigw', category: 'Azure subscription 1' },
    { resourceName: 'RedHat', resourceType: 'Subscription', resourceTypeName: 'HighAvailability', impact: 'Medium', subscription: 'Rgroup2', category: 'Azure subscription 1' },
    { resourceName: 'ubntu', resourceType: 'Subscription', resourceTypeName: 'HighAvailability', impact: 'Medium', subscription: 'Rgroup1', category: 'Azure subscription 1' },
  ];
  chart: any;


  breadcrumbs: BreadcrumbsItem[] = [
    { label: 'Home', url: '/' },
    { label: 'analytics', url: '' },
  ];


  selectedSummary: number | null = null;

  constructor(private router: Router) { }


  showUserData(summaryIndex: number): void {
    this.selectedSummary = summaryIndex;
    if (summaryIndex === 1) {
      this.router.navigate(["/analytics"]);
    }
    if (summaryIndex === 2) {
      this.router.navigate(["/analytics."]);
    }
    if (summaryIndex === 3) {
      this.router.navigate(["/analytics.."]);
    }
  }



  ngOnInit(): void {
    const defaultSummaryIndex = 4;
    this.showUserData(defaultSummaryIndex);
    this.showUserData(defaultSummaryIndex);




    Highcharts.chart('container1', {
      series: [
        {
          type: 'treemap',
          layoutAlgorithm: 'stripes',
          layoutStartingDirection: 'horizontal',
          alternateStartingDirection: true,
          borderColor: '#fff',
          borderRadius: 0,
          borderWidth: 2,
          dataLabels: {
            style: {
              textOutline: 'none',
            },
            formatter: function () {
              if (this.point.name === 'Medium') {
                return '<span style="color: #9f734f; font-size: 30px;">' + this.point.name + '</span>';
              } else if (this.point.name === 'High') {
                return '<span style="color: #a35251;">' + this.point.name + '</span>';
              } else if (this.point.name === 'Low') {
                return '<span style="color: #a7a561; font-size: 15px;">' + this.point.name + '</span>';
              } else {
                return this.point.name;
              }
            },
          },
          levels: [
            {
              level: 1,
              layoutAlgorithm: 'sliceAndDice',
              dataLabels: {
                enabled: true,
                align: 'left',
                verticalAlign: 'top',
                style: {
                  fontSize: '13px',
                  fontWeight: 'normal',
                },
              },
            },
          ],
          data: [
            {
              id: 'A',
              name: 'Subscription',
              color: '#ffa65e',

            },
            {
              id: 'B',
              name: 'Virtual Machine',
              color: '#fffa66',
            },
            {
              id: 'C',
              name: 'Subscription',
              color: '#ff5654',
             
            },
            {
              name: 'Medium',
              title: 'High Availability',
              parent: 'A',
              value: 8,
            },
            {
              name: 'Low',
              title: 'High Availability',
              parent: 'B',
              value: 1,
            },
            {
              name: 'Low',
              title: 'Cost',
              parent: 'B',
              value: 1,
            },
            {
              name: 'High',
              title: 'Operational Expenses',
              parent: 'C',
              value: 1,
            },
          ],
        },
      ],
      title: {
        text: 'coloured by number of recommendations',
        align: 'left',
        style: {
          fontSize: '15px',
          fontWeight: 'normal',
        },
      },
      tooltip: {
        useHTML: true,
        pointFormat: '<b>{point.title}</b><b>{point.value}</b>',
      },
    });
    
  }
}