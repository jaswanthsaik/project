import { Component, OnInit } from "@angular/core";
import { ActivatedRoute ,Router} from '@angular/router';
import * as am5 from '@amcharts/amcharts5';
import * as am5xy from '@amcharts/amcharts5/xy';
import * as am5themes_Animated from '@amcharts/amcharts5/themes/Animated';
import { BreadcrumbsItem } from "src/app/shared/models/breadcrumbs-item";

@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.scss']
})


export class analytics implements OnInit {
  chart: any;


  breadcrumbs: BreadcrumbsItem[] = [
    { label: 'Home', url: '/' },
    { label: 'analytics', url: '' },
  ];


  selectedSummary: number | null = null;

  constructor(private router: Router) {}


  showUserData(summaryIndex: number): void {
    this.selectedSummary = summaryIndex;
    if (summaryIndex === 2) {
      this.router.navigate(["/analytics."]);
    }
    if (summaryIndex === 3) {
      this.router.navigate(["/analytics.."]);
    }
    if (summaryIndex === 4) {
      this.router.navigate(["/analytics..."]);
    }
  }
  

  ngOnInit(): void {
    const defaultSummaryIndex = 1;
    this.showUserData(defaultSummaryIndex);
    this.showUserData(defaultSummaryIndex);

    // Chart 1 - chartdiv
    let root1 = am5.Root.new("chartdiv");

    let chart1 = root1.container.children.push(am5xy.XYChart.new(root1, {
      panX: false,
      panY: false,
      wheelX: "panX",
      wheelY: "zoomX",
      layout: root1.verticalLayout
    }));

    let xRenderer1 = am5xy.AxisRendererX.new(root1, {});

    let xAxis1 = chart1.xAxes.push(am5xy.CategoryAxis.new(root1, {
      categoryField: "year",
      renderer: xRenderer1,
      tooltip: am5.Tooltip.new(root1, {})
    }));

    xRenderer1.grid.template.setAll({
      location: 1
    });

    let data1 = [
      {
      "year": "East US",
      "scheduled and scaled": 0.110,
      "scheduled only": 0.18,
      "scaled only": 0.110,
      "neither": 0.110,
      "white": 3.1,
    }
  ];

    xAxis1.data.setAll(data1);

    let yAxis1 = chart1.yAxes.push(am5xy.ValueAxis.new(root1, {
      min: 0,
      max: 14,
      strictMinMax: true,
      calculateTotals: true,
      renderer: am5xy.AxisRendererY.new(root1, {
        strokeOpacity: 0.1
      })
    }));

    let legend1 = chart1.children.unshift(am5.Legend.new(root1, {
      centerX: am5.p50,
      x: am5.p50,
    }));

    function makeSeries1(name: string, fieldName: string, color: am5.Color, columnWidth: number) {
      let series1 = chart1.series.push(am5xy.ColumnSeries.new(root1, {
        name: name,
        stacked: true,
        xAxis: xAxis1,
        yAxis: yAxis1,
        valueYField: fieldName,
        valueYShow: "valueYTotalPercent",
        categoryXField: "year",
        fill: color,
      }));

      series1.columns.template.set("width", am5.percent(columnWidth * 18));

      series1.columns.template.setAll({
        tooltipText: "{categoryX}\n{name}:{valueYTotalPercent.formatNumber('#.#')}",
        tooltipY: am5.percent(1)
      });

      series1.data.setAll(data1);
      series1.appear();
      series1.bullets.push(function () {
        return am5.Bullet.new(root1, {
          sprite: am5.Label.new(root1, {
            text: "{valueYTotalPercent.formatNumber('#.#')}",
            fill: root1.interfaceColors.get("alternativeText"),
            centerY: am5.p50,
            centerX: am5.p50,
            populateText: true
          })
        });
      });

      legend1.data.push(series1);
    }

    makeSeries1("scheduled and scaled", "scheduled and scaled", am5.color("#006580"), 0.6);
    makeSeries1("scheduled only", "scheduled only", am5.color("#e0bd8d"), 0.6);
    makeSeries1("scaled only", "scaled only", am5.color("#10cfc9"), 0.6);
    makeSeries1("neither", "neither", am5.color("#87205d"), 0.6);
    makeSeries1("", "white", am5.color("#ffffff"), 0.6);

    chart1.appear(1000);

    // Chart 2 - chartdiv1
    let root2 = am5.Root.new("chartdiv1");

    let myTheme = am5.Theme.new(root2);

    myTheme.rule("Grid", ["base"]).setAll({
      strokeOpacity: 0.1
    });

    let chart2 = root2.container.children.push(am5xy.XYChart.new(root2, {
      panX: false,
      panY: false,
      wheelX: "panY",
      wheelY: "zoomY",
      layout: root2.verticalLayout
    }));

    let data2 = [{
      "year": "Dev Ensar Accounts",
      "europe": 8,
    }];

    let yRenderer2 = am5xy.AxisRendererY.new(root2, {});
    let yAxis2 = chart2.yAxes.push(am5xy.CategoryAxis.new(root2, {
      categoryField: "year",
      renderer: yRenderer2,
      tooltip: am5.Tooltip.new(root2, {})
    }));

    yRenderer2.grid.template.setAll({
      location: 1
    });

    yAxis2.data.setAll(data2);

    let xAxis2 = chart2.xAxes.push(am5xy.ValueAxis.new(root2, {
      min: 0,
      renderer: am5xy.AxisRendererX.new(root2, {
        strokeOpacity: 0.1
      })
    }));

    let legend2 = chart2.children.push(am5.Legend.new(root2, {
      centerX: am5.p50,
      x: am5.p50,
    }));

    function makeSeries2(name: string, fieldName: string, color: am5.Color,) {
      let series2 = chart2.series.push(am5xy.ColumnSeries.new(root2, {
        name: name,
        stacked: true,
        xAxis: xAxis2,
        yAxis: yAxis2,
        baseAxis: yAxis2,
        valueXField: fieldName,
        categoryYField: "year",
        fill: color
      }));
    
      series2.columns.template.set("width", am5.percent(100)); 
      series2.columns.template.set("height", am5.percent(30));

      series2.columns.template.setAll({
        tooltipText: "{name}, {categoryY}: {valueX}",
        tooltipY: am5.percent(90)
      });
      series2.data.setAll(data2);

      series2.appear();

      series2.bullets.push(function() {
        return am5.Bullet.new(root2, {
          sprite: am5.Label.new(root2, {
            text: "{valueX}",
            fill: root2.interfaceColors.get("alternativeText"),
            centerY: am5.p50,
            centerX: am5.p50,
            populateText: true
          })
        });
      });
    }

    makeSeries2("", "europe",am5.color("#006580"));

    chart2.appear(1000, 100);
  }
}