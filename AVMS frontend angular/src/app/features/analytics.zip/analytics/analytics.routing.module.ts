// analytics.routing.module.ts

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { analyticsComponent } from './analytics.component';
import { analytics } from './analytics.component';
// import { manageByExceptions } from './manageByExceptions.component';

const routes: Routes = [
  {
    path: '',
    component: analytics,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class analyticsRoutingModule {}
